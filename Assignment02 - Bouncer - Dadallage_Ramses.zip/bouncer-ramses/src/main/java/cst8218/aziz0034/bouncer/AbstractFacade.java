/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cst8218.aziz0034.bouncer;

import java.util.List;
import javax.persistence.EntityManager;

/**
 * This abstract class serves as a base for creating a facade to interact with entities.
 * It provides common CRUD (Create, Read, Update, Delete) operations and other utility functions.
 *
 * @param <T> The type of entity this facade interacts with.
 * @author Ramses Aziz
 * @author Dadallage Samarasinghe
 */
public abstract class AbstractFacade<T> {

    private Class<T> entityClass;

    /**
     * Constructor to initialize the entity class type.
     *
     * @param entityClass The class type of the entity this facade interacts with.
     */
    public AbstractFacade(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    /**
     * Protected method to obtain the entity manager for performing database operations.
     *
     * @return The entity manager associated with the subclass's persistence context.
     */
    protected abstract EntityManager getEntityManager();

    /**
     * Creates and persists a new entity in the database.
     *
     * @param entity The entity to be created and persisted.
     */
    public void create(T entity) {
        getEntityManager().persist(entity);
    }

    /**
     * Updates an existing entity in the database.
     *
     * @param entity The entity to be updated.
     */
    public void edit(T entity) {
        getEntityManager().merge(entity);
    }

    /**
     * Removes an entity from the database.
     *
     * @param entity The entity to be removed.
     */
    public void remove(T entity) {
        getEntityManager().remove(getEntityManager().merge(entity));
    }

    /**
     * Retrieves an entity from the database based on its ID.
     *
     * @param id The ID of the entity to be retrieved.
     * @return The retrieved entity, or null if not found.
     */
    public T find(Object id) {
        return getEntityManager().find(entityClass, id);
    }

    /**
     * Retrieves a list of all entities in the database.
     *
     * @return A list containing all entities.
     */
    public List<T> findAll() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        cq.select(cq.from(entityClass));
        return getEntityManager().createQuery(cq).getResultList();
    }

    /**
     * Retrieves a range of entities from the database based on a specified range.
     *
     * @param range An array containing the range of results to retrieve.
     * @return A list of entities within the specified range.
     */
    public List<T> findRange(int[] range) {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        cq.select(cq.from(entityClass));
        javax.persistence.Query q = getEntityManager().createQuery(cq);
        q.setMaxResults(range[1] - range[0] + 1);
        q.setFirstResult(range[0]);
        return q.getResultList();
    }

    /**
     * Counts the total number of entities in the database.
     *
     * @return The count of entities.
     */
    public int count() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        javax.persistence.criteria.Root<T> rt = cq.from(entityClass);
        cq.select(getEntityManager().getCriteriaBuilder().count(rt));
        javax.persistence.Query q = getEntityManager().createQuery(cq);
        return ((Long) q.getSingleResult()).intValue();
    }
}

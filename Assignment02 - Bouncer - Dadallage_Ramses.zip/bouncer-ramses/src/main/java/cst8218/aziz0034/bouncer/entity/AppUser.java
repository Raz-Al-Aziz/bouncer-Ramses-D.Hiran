package cst8218.aziz0034.bouncer.entity;

import cst8218.aziz0034.bouncer.LanguageBean;
import java.io.Serializable;
import java.util.HashMap;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.spi.CDI;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

/**
 * Entity class representing an application user with user authentication information.
 * This class also handles user login and password hashing.
 *
 * Serializable: Allows instances of this class to be serialized and deserialized.
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "AppUser.findAll", query = "SELECT a FROM AppUser a"),
    @NamedQuery(name = "AppUser.findByUserid", query = "SELECT a FROM AppUser a WHERE a.userid = :userid"),
    @NamedQuery(name = "AppUser.count", query = "SELECT COUNT(a) FROM AppUser a")
})
public class AppUser implements Serializable {

     @Inject
    private LanguageBean languageBean; 
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Indicates auto-generated ID
    @Column(name = "id") // Maps this field to a column in the database
    private Long id; // User ID

    @NotNull
    @Column(name = "userid", unique = true) // Maps this field to a column in the database
    private String userid; // User's unique identifier

    @NotNull
    @Column(name = "password") // Maps this field to a column in the database
    private String password; // User's password

    @NotNull
    @Column(name = "groupname") // Maps this field to a column in the database
    private String groupname; // User's group name

    /**
     * Gets the user's ID.
     *
     * @return The user's ID.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the user's ID.
     *
     * @param id The user's ID to set.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the user's unique identifier.
     *
     * @return The user's unique identifier.
     */
    public String getUserid() {
        return userid;
    }

    /**
     * Sets the user's unique identifier.
     *
     * @param userid The user's unique identifier to set.
     */
    public void setUserid(String userid) {
        this.userid = userid;
    }

    /**
     * Gets the user's password.
     *
     * @return An empty string to avoid returning the actual password in the getter.
     */
    public String getPassword() {
        return ""; // Avoid returning the actual password in the getter
    }

    /**
     * Sets the user's password and hashes it using the PasswordHash utility if not empty.
     *
     * @param plainTextPassword The plain text password to set and hash.
     */
    public void setPassword(String plainTextPassword) {
        if (!plainTextPassword.isEmpty()) {
            this.password = hashPassword(plainTextPassword);
        }
    }

    /**
     * Gets the user's group name.
     *
     * @return The user's group name.
     */
    public String getGroupname() {
        return groupname;
    }

    /**
     * Sets the user's group name.
     *
     * @param groupname The user's group name to set.
     */
    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    
/**
     * Attempts user login using Java EE HttpServletRequest authentication.
     *
     * @return "success" if login succeeds, "failure" if login fails.
     */
    public String login() {
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();

        try {
            request.login(userid, password);

            // Successful login
            // languageBean.changeLanguage(); // Missing reference to a languageBean instance
            return "success"; // Return the navigation outcome for successful login
        } catch (ServletException e) {
            // Failed login
            e.printStackTrace();
            return "failure"; // Return the navigation outcome for failed login
        }
    }

   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof AppUser)) {
            return false;
        }
        AppUser other = (AppUser) object;
        return (this.id != null || other.id == null) && (this.id == null || this.id.equals(other.id));
    }

    @Override
    public String toString() {
        return "AppUser.AppUser[ id=" + id + " ]";
    }
 
 /**
     * Generates the hash of a plain text password using the PasswordHash utility provided by Jakarta Security Enterprise.
     *
     * @param plainTextPassword The plain text password to be hashed.
     * @return The hashed password.
     */
    private String hashPassword(String plainTextPassword) {
        Instance<? extends PasswordHash> instance = CDI.current().select(PasswordHash.class);
        PasswordHash passwordHash = instance.get();
        passwordHash.initialize(new HashMap<>()); // todo: customize as needed
        return passwordHash.generate(plainTextPassword.toCharArray());
    }

    // hashCode, equals, and toString methods omitted for brevity
}

    


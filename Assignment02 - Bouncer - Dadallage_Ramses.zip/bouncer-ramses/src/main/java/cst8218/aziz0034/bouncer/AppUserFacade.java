package cst8218.aziz0034.bouncer;

import cst8218.aziz0034.bouncer.entity.AppUser;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.security.enterprise.identitystore.PasswordHash;

/**
 * Stateless session bean responsible for managing operations related to the AppUser entity.
 *
 * @author Ramses Aziz
 * @author Dadallage Samarasinghe
 */
@Stateless
public class AppUserFacade extends AbstractFacade<AppUser> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @Inject
    private PasswordHash passwordHash;

    /**
     * Default constructor initializing the AppUserFacade with the AppUser entity class.
     */
    public AppUserFacade() {
        super(AppUser.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Overrides the create method to set the hashed password using the PasswordHash utility provided by Jakarta Security Enterprise.
     *
     * @param appUser The AppUser entity to be created.
     */
    @Override
    public void create(AppUser appUser) {
        // Set the hashed password before persisting the entity
        setPasswordHash(appUser);
        super.create(appUser);
    }

    /**
     * Overrides the edit method to set the hashed password using the PasswordHash utility provided by Jakarta Security Enterprise,
     * only if a new password is provided.
     *
     * @param appUser The AppUser entity to be updated.
     */
    @Override
    public void edit(AppUser appUser) {
        // Check if a new password is provided and it's different from the current hashed password
        if (!appUser.getPassword().isEmpty() && !isPasswordSame(appUser)) {
            // Set the hashed password before merging the entity
            setPasswordHash(appUser);
        }
        super.edit(appUser);
    }

    /**
     * Sets the hashed password for the given AppUser entity using the PasswordHash utility provided by Jakarta Security Enterprise.
     * Initializes the PasswordHash object and generates a password entry for the given plain-text password.
     *
     * @param appUser The AppUser entity for which to set the hashed password.
     */
    private void setPasswordHash(AppUser appUser) {
        // Ensure the password is not empty before setting the hashed value
        if (!appUser.getPassword().isEmpty()) {
            passwordHash.initialize(new HashMap<>()); // todo: are the defaults good enough?
            appUser.setPassword(passwordHash.generate(appUser.getPassword().toCharArray()));
        }
    }

    /**
     * Checks if the new password provided by the user is the same as the current password.
     *
     * @param appUser The AppUser entity with the new password.
     * @return True if the new password is the same as the current password, false otherwise.
     */
    private boolean isPasswordSame(AppUser appUser) {
        AppUser existingUser = find(appUser.getId());
        return existingUser != null && existingUser.getPassword().equals(appUser.getPassword());
    }
}

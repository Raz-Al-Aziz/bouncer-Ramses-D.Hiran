/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.aziz0034.bouncer.tests;

import cst8218.aziz0034.bouncer.entity.AppUser;
import org.junit.Test;

/**
 * This class contains JUnit tests for the AppUser entity class.
 * These tests cover the setPassword and login methods.
 * 
 * Note: This class assumes that the AppUser entity class has been properly implemented.
 * Please adjust the tests and assertions based on the behavior of your AppUser class.
 * 
 * @author Ramses
 * @author Hiran
 */
public class AppUserTest {

    @Test
    public void testSetPassword() {
        AppUser user = new AppUser();
        user.setPassword("password123");

        // The password should be hashed and set
        assertNotNull(user.getPassword());
        assertNotEquals("password123", user.getPassword());
    }

    @Test
    public void testLoginSuccessful() {
        AppUser user = new AppUser();
        user.setUserid("user123");
        user.setPassword("password123");

        String outcome = user.login();

        // The login should succeed and return "success"
        assertEquals("success", outcome);
    }

    @Test
    public void testLoginFailed() {
        AppUser user = new AppUser();
        user.setUserid("user123");
        user.setPassword("wrongpassword");

        String outcome = user.login();

        // The login should fail and return "failure"
        assertEquals("failure", outcome);
    }

    private void assertEquals(String failure, String outcome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void assertNotNull(String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void assertNotEquals(String password123, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

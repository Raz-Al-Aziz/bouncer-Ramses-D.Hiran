package cst8218.aziz0034.bouncer;

import javax.enterprise.context.ApplicationScoped;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.security.enterprise.authentication.mechanism.http.LoginToContinue;
import javax.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Application configuration class.
 */
@ApplicationPath("resources")
@BasicAuthenticationMechanismDefinition(realmName = "AppUserRealm")
@DatabaseIdentityStoreDefinition(
    dataSourceLookup = "${'java:comp/DefaultDataSource'}",
    callerQuery = "#{'select password from app.appuser where userid = ?'}",
    groupsQuery = "select groupname from app.appuser where userid = ?",
    hashAlgorithm = PasswordHash.class,
    priority = 10
)
@LoginToContinue(
    loginPage = "/Login.xhtml",
    useForwardToLogin = false,
    errorPage = ""
)
public class JarkartaRestConfiguration extends Application {
    
}

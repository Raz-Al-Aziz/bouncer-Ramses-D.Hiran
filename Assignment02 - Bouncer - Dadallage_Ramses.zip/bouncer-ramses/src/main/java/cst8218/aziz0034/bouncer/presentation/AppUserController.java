package cst8218.aziz0034.bouncer.presentation;

import cst8218.aziz0034.bouncer.entity.AppUser;

import java.io.Serializable;
import java.util.ResourceBundle;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

/**
 * AppUserController is a controller class responsible for managing interactions
 * between the user interface and the AppUser entity.
 *
 * This controller class handles CRUD operations (Create, Read, Update, Delete) for AppUser entities.
 * It also manages pagination and provides utility methods for the user interface.
 */
@Named("appUserController")
@SessionScoped
public class AppUserController implements Serializable {

    private AppUser current;
    private DataModel items = null;
    @EJB
    private cst8218.aziz0034.bouncer.AppUserFacade ejbFacade;
    private PaginationHelper pagination;
    private int selectedItemIndex;

    public AppUserController() {
    }

    /**
     * Returns the currently selected AppUser entity. If no entity is selected, a new one is created.
     *
     * @return the currently selected AppUser entity
     */
    public AppUser getSelected() {
        if (current == null) {
            current = new AppUser();
            selectedItemIndex = -1;
        }
        return current;
    }

    private cst8218.aziz0034.bouncer.AppUserFacade getFacade() {
        return ejbFacade;
    }

    /**
     * Gets the PaginationHelper instance for managing pagination of AppUser entities.
     *
     * @return the PaginationHelper instance
     */
    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(10) {

                @Override
                public int getItemsCount() {
                    return getFacade().count();
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getFacade().findRange(new int[]{getPageFirstItem(), getPageFirstItem() + getPageSize()}));
                }
            };
        }
        return pagination;
    }

    /**
     * Prepares the user interface for displaying a list of AppUser entities.
     *
     * @return the navigation outcome for displaying the list view
     */
    public String prepareList() {
        recreateModel();
        return "List";
    }

    /**
     * Prepares the user interface for displaying a single AppUser entity view.
     *
     * @return the navigation outcome for displaying the view
     */
    public String prepareView() {
        current = (AppUser) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "View";
    }

    /**
     * Prepares the user interface for creating a new AppUser entity.
     *
     * @return the navigation outcome for displaying the create view
     */
    public String prepareCreate() {
        current = new AppUser();
        selectedItemIndex = -1;
        return "Create";
    }

    /**
     * Creates a new AppUser entity and persists it in the database.
     *
     * @return the navigation outcome after the create operation
     */
    public String create() {
        try {
            getFacade().create(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("AppUserCreated"));
            return prepareCreate();
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    /**
     * Prepares the user interface for editing an existing AppUser entity.
     *
     * @return the navigation outcome for displaying the edit view
     */
    public String prepareEdit() {
        current = (AppUser) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "Edit";
    }

    /**
     * Updates an existing AppUser entity in the database.
     *
     * @return the navigation outcome after the update operation
     */
    public String update() {
        try {
            getFacade().edit(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("AppUserUpdated"));
            return "View";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    /**
     * Deletes the currently selected AppUser entity from the database.
     *
     * @return the navigation outcome after the delete operation
     */
    public String destroy() {
        current = (AppUser) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        performDestroy();
        recreatePagination();
        recreateModel();
        return "List";
    }

    /**
     * Deletes the currently selected AppUser entity from the database and displays the list view.
     *
     * @return the navigation outcome after the delete operation
     */
    public String destroyAndView() {
        performDestroy();
        recreateModel();
        updateCurrentItem();
        if (selectedItemIndex >= 0) {
            return "View";
        } else {
            // all items were removed - go back to list
            recreateModel();
            return "List";
        }
    }

    private void performDestroy() {
        try {
            getFacade().remove(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("AppUserDeleted"));
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
        }
    }

    private void updateCurrentItem() {
        int count = getFacade().count();
        if (selectedItemIndex >= count) {
            // selected index cannot be bigger than number of items:
            selectedItemIndex = count - 1;
            // go to the previous page if the last page disappeared:
            if (pagination.getPageFirstItem() >= count) {
                pagination.previousPage();
            }
        }
        if (selectedItemIndex >= 0) {
            current = getFacade().findRange(new int[]{selectedItemIndex, selectedItemIndex + 1}).get(0);
        }
    }

    /**
     * Retrieves the DataModel containing AppUser entities for the current page.
     * If the DataModel doesn't exist, it will be created.
     *
     * @return the DataModel for AppUser entities
     */
    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    private void recreateModel() {
        items = null;
    }

    private void recreatePagination() {
        pagination = null;
    }

    /**
     * Navigates to the next page of AppUser entities.
     *
     * @return the navigation outcome for the next page
     */
    public String next() {
        getPagination().nextPage();
        recreateModel();
        return "List";
    }

    /**
     * Navigates to the previous page of AppUser entities.
     *
     * @return the navigation outcome for the previous page
     */
    public String previous() {
        getPagination().previousPage();
        recreateModel();
        return "List";
    }

    /**
     * Retrieves an array of SelectItem objects representing all AppUser entities for selection.
     *
     * @return an array of SelectItem objects for all AppUser entities
     */
    public SelectItem[] getItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
    }

    /**
     * Retrieves an array of SelectItem objects representing all AppUser entities for selection.
     *
     * @return an array of SelectItem objects for all AppUser entities
     */
    public SelectItem[] getItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
    }

    /**
     * Retrieves an AppUser entity by its ID.
     *
     * @param id the ID of the AppUser entity to retrieve
     * @return the AppUser entity if found, or null if not found
     */
    public AppUser getAppUser(java.lang.Long id) {
        return ejbFacade.find(id);
    }

    @FacesConverter(forClass = AppUser.class)
    public static class AppUserControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            AppUserController controller = (AppUserController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "appUserController");
            return controller.getAppUser(getKey(value));
        }

        java.lang.Long getKey(String value) {
            java.lang.Long key;
            key = Long.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Long value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof AppUser) {
                AppUser o = (AppUser) object;
                return getStringKey(o.getId());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + AppUser.class.getName());
            }
        }

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cst8218.aziz0034.bouncer;

import cst8218.aziz0034.bouncer.entity.Bouncer;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Stateless session bean responsible for managing operations related to the Bouncer entity.
 *
 * @author Ramses Aziz
 * @author Dadallage Samarasinghe
 */
@Stateless
public class BouncerFacade extends AbstractFacade<Bouncer> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    /**
     * Retrieves the entity manager for performing database operations.
     *
     * @return The entity manager associated with this facade's persistence context.
     */
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Default constructor initializing the BouncerFacade with the Bouncer entity class.
     */
    public BouncerFacade() {
        super(Bouncer.class);
    }
    
}

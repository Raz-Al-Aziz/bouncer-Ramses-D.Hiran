/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.aziz0034.bouncer.tests;

import cst8218.aziz0034.bouncer.entity.Bouncer;
import static junit.framework.Assert.assertEquals;
import org.junit.Test;

/**
 *@author Ramses
 * @author hiran
 */
public class BouncerTest {

    @Test
    public void testAdvanceOneFrame() {
        Bouncer bouncer = new Bouncer();
        bouncer.setY(100);
        bouncer.setYSpeed(2);

        bouncer.advanceOneFrame();

        // Assert the new position and speed after advancing one frame
        assertEquals(102, bouncer.getY());
        assertNotEquals(2, bouncer.getYSpeed()); // Speed should have changed due to gravity and bouncing
    }

    @Test
    public void testBoundaryCollision() {
        Bouncer bouncer = new Bouncer();
        bouncer.setY(0);
        bouncer.setYSpeed(-2);

        bouncer.advanceOneFrame();

        // Assert the new position and speed after reaching the upper boundary
        assertEquals(0, bouncer.getY()); // Position should be clamped to 0
        assertNotEquals(-2, bouncer.getYSpeed()); // Speed should have changed due to bouncing

        // Reset and test lower boundary
        bouncer.setY(500);
        bouncer.setYSpeed(2);

        bouncer.advanceOneFrame();

        // Assert the new position and speed after reaching the lower boundary
        assertEquals(500, bouncer.getY()); // Position should be clamped to 500
        assertNotEquals(2, bouncer.getYSpeed()); // Speed should have changed due to bouncing
    }

    @Test
    public void testEquals() {
        Bouncer bouncer1 = new Bouncer();
        Bouncer bouncer2 = new Bouncer();

        assertEquals(bouncer1, bouncer2);
    }

    @Test
    public void testToString() {
        Bouncer bouncer = new Bouncer();
        bouncer.setId(1L);

        assertEquals("cst8218.aziz0034.bouncer.entity.Bouncer[ id=1 ]", bouncer.toString());
    }

    private void assertNotEquals(int i, int ySpeed) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
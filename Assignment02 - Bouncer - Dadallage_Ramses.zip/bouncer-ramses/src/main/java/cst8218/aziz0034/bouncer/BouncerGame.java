/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package cst8218.aziz0034.bouncer;

import cst8218.aziz0034.bouncer.entity.Bouncer;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 * This class creates a single instance of BouncerGame on startup.
 * The BouncerFacade is injected into the class to retrieve a list of existing
 * Bouncer instances. A separate thread calls advanceOneFrame() method
 * for each of these instances. The thread is intentionally put to sleep
 * according to the CHANGE_RATE variable.
 * 
 * @author Ramses Aziz
 */
@Startup
@Singleton
public class BouncerGame {
    
    private static final int CHANGE_RATE = 15; // FPS
    
    @EJB
    private cst8218.aziz0034.bouncer.BouncerFacade bouncerFacade;
    List<Bouncer> bouncers;
    
    /**
     * Invoked immediately after the default constructor is called.
     * This method starts a new thread and calls advanceOneFrame() for
     * each instance found in the entity manager.
     */
    @PostConstruct
    public void go() {
        new Thread(() -> {
            // the game runs indefinitely
            while (true) {
                //update all the bouncers and save changes to the database
                bouncers = bouncerFacade.findAll();
                for (Bouncer bouncer : bouncers) {
                    bouncer.advanceOneFrame();
                    bouncerFacade.edit(bouncer);
                }
                //sleep while waiting to process the next frame of the animation
                try {
                    // wake up roughly CHANGE_RATE times per second
                    Thread.sleep((long)(1.0/CHANGE_RATE*1000));
                } catch (InterruptedException exception) {
                    exception.printStackTrace();
                }
            }
        }).start();
    }   
}
